package ru.icmit.oodb.lab10.repository;

import org.springframework.stereotype.Component;
import ru.icmit.oodb.lab10.domain.Client;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Component
public class ClientRepository {

    @PersistenceContext(name = "entityManagerFactory")
    protected EntityManager entityManager;

    public List<Client> findAll() {

        Query query = entityManager.createQuery(
                "select c from Client c ", Client.class);

        List<Client> clients = query.getResultList();

        return clients;

    }

    public Client findByName(String name) {
        Query query = entityManager.createQuery(
                "select c from Client c where c.name like :name ", Client.class);

        query.setParameter("name", name);

/*
        List<Client> clients = query.getResultList();

        Client client = clients!=null?clients.get(0):null;
*/

        Client client = (Client) query.getSingleResult();

        return client;
    }

}
