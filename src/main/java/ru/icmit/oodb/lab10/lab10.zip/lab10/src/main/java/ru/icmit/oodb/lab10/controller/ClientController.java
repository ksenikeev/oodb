package ru.icmit.oodb.lab10.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.icmit.oodb.lab10.domain.Client;
import ru.icmit.oodb.lab10.repository.ClientRepository;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class ClientController {

    @Autowired
    private ClientRepository repository;

    @RequestMapping("/client")
    public String clients(HttpServletRequest request, @ModelAttribute("model") ModelMap model) {

        String path = request.getContextPath();

        model.addAttribute("app_path", path);


        List<Client> clients = repository.findAll();

        model.addAttribute("clients", clients);

        return "/clients";
    }

    @RequestMapping("/clientbyname")
    public String clientByName(HttpServletRequest request,
                               @RequestParam("name") String name,
                               @ModelAttribute("model") ModelMap model) {

        String path = request.getContextPath();

        model.addAttribute("app_path", path);


        System.out.println("name " + name);
        Client client = repository.findByName(name);

        System.out.println(client);

        model.addAttribute("client", client);

        return "/clientbyname";
    }



}
