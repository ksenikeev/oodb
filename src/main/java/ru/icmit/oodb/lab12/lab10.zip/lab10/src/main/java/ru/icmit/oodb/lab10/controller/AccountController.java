package ru.icmit.oodb.lab10.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.icmit.oodb.lab10.domain.Account;
import ru.icmit.oodb.lab10.domain.Client;
import ru.icmit.oodb.lab10.repository.AccountRepository;
import ru.icmit.oodb.lab10.repository.ClientRepository;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@Controller
public class AccountController {

    @Autowired
    private ClientRepository clientRepository;

    @Autowired
    private AccountRepository accountRepository;


    @RequestMapping("/addaccount")
    @Transactional
    public String clientByName(HttpServletRequest request,
                               @RequestParam(value = "id", required = false) Long id,
                               @RequestParam(value = "numb", required = false) String numb,
                               @ModelAttribute("model") ModelMap model)
    {

        String path = request.getContextPath();
        model.addAttribute("app_path", path);

        Client client = null;
        // Если получили непустой id - пытаемся найти клиента к которому надо привязать счет
        if (id != null) {
            client = clientRepository.findById(id);

            // Если нашли клиента - добавляем счет
            if (client != null) {
                Account account = new Account();
                account.setClient( client );
                account.setAccountNumber( numb );
                accountRepository.save( account );
            }

            // Запросим теперь список всех счетов клиента
            List<Account> accounts = accountRepository.findClientsAccount( client );
            // Передаем в параметры веб-страницы
            model.addAttribute("accounts", accounts);

        } else {
            client = new Client();
        }

        model.addAttribute("client", client);

        return "/client";
    }




}
