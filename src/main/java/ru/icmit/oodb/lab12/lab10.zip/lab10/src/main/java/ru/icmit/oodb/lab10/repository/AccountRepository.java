package ru.icmit.oodb.lab10.repository;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import ru.icmit.oodb.lab10.domain.Account;
import ru.icmit.oodb.lab10.domain.AccountTransaction;
import ru.icmit.oodb.lab10.domain.Client;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Component
public class AccountRepository {

    @PersistenceContext(name = "entityManagerFactory")
    protected EntityManager entityManager;

    public List<Account> findClientsAccount(Client client) {

        Query query = entityManager.createQuery(
                "select a from Account a where a.client = :client ", Account.class);

        query.setParameter("client", client);
        List<Account> accounts = query.getResultList();

        return accounts;

    }


    @Transactional
    public Account save(Account account) {
        if (account != null && account.getId() != null) {
            account = entityManager.merge(account);
        } else {
            entityManager.persist(account);
        }

        return account;
    }

    @Transactional
    public AccountTransaction save(AccountTransaction accountTransaction) {
        if (accountTransaction != null && accountTransaction.getId() != null) {
            accountTransaction = entityManager.merge(accountTransaction);
        } else {
            entityManager.persist(accountTransaction);
        }

        return accountTransaction;
    }

}
