package ru.icmit.oodb.lab10.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.icmit.oodb.lab10.domain.Account;
import ru.icmit.oodb.lab10.domain.AccountTransaction;
import ru.icmit.oodb.lab10.domain.Client;
import ru.icmit.oodb.lab10.repository.AccountRepository;
import ru.icmit.oodb.lab10.repository.ClientRepository;
import javax.servlet.http.HttpServletRequest;
import java.util.Date;

@Controller
public class IndexController {


    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private ClientRepository clientRepository;

    @RequestMapping("/")
    //@Transactional
    public String index(HttpServletRequest request,
                        @ModelAttribute("model") ModelMap model) {

        String path = request.getContextPath();

        model.addAttribute("app_path", path);

/*
        Client client = new Client();
        client.setName("Клиент 1");

        Account account1 = new Account();
        account1.setAccountNumber("11111111111");
        account1.setClient(client);
        accountRepository.save(account1);

        client.setAddress("Москва");

        Account account2 = new Account();
        account2.setAccountNumber("222222222");
        account2.setClient(client);
        accountRepository.save(account2);


        AccountTransaction accountTransaction = new AccountTransaction();
        accountTransaction.setDestantionAccount(account2);
        accountTransaction.setSourceAccount(account1);
        accountTransaction.setTransactionDate(new Date());
        accountTransaction.setTransationSum(100D);
        accountRepository.save(accountTransaction);
*/
/*
        1.  Генерация первичного ключа
            (1) своя последовательность
            (2) последовательность от Hibernate на несколько таблиц
            (3) уникальная последовательность - генерация на стороне СУБД

        2. Каскадные операции сохранения и обновления
            (атрибут cascade @ManyToOne)

        3. Транзакции ("вовлечение" в транзакцию)
*/

        return "/index";
    }

}
